#!/bin/bash
nohup ./startEA.sh &