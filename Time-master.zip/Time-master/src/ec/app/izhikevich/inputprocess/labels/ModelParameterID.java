package ec.app.izhikevich.inputprocess.labels;

public enum ModelParameterID {
	K, A, B, D, CM, VR, VT, VMIN, VPEAK, G, P, W, I
	,	I_dur
}
