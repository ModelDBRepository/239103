package ec.app.izhikevich.inputprocess.labels;

public enum BurstFeatureID {
	nspikes,
	sfa_m,
	sfa_b,
	nsfa,
	b_w,
	pbi,
	pbi_vmin_offset
}
