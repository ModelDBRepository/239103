package ec.app.izhikevich.inputprocess.labels;

public enum PhenotypeConstraintAttributeID {
	type,
	INCLUDE,
	//excitability
	current_min,
	current_max,
	current_duration,
	current_step,
	min_freq,
	
	cons_weight
}
