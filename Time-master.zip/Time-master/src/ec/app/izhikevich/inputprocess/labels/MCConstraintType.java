package ec.app.izhikevich.inputprocess.labels;

public enum MCConstraintType {
	EXCITABILITY, INP_RES, PROPAGATION, BACK_PROPAGATION, SYN_STIM_EPSP
}
