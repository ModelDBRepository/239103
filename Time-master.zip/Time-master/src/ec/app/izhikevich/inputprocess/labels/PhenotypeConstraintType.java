package ec.app.izhikevich.inputprocess.labels;

public enum PhenotypeConstraintType {
	FAST_SPIKER
}
