package ec.app.izhikevich.outputprocess;

public enum CarlMcSimDataLabels {
	ramp_rheos, v_defs, spike_proped, epsps
}
