package ec.app.izhikevich.outputprocess;

public enum CarlSomaPatternLabels {
	notes, I, I_dur, t_step, v_trace, spike_times
}
