package ec.app.izhikevich.spike.labels;


public enum SpikePatternComponent {
	ASP,NASP,
	D,SLN,
	TSTUT,PSTUT,
	TSWB,PSWB,
	RASP,
	X, 
	EMPTY;
	//public Map<PatternFeatureID, Double> properties = new HashMap<>();
}
