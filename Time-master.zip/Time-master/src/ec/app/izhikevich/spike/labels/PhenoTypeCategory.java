package ec.app.izhikevich.spike.labels;

public enum PhenoTypeCategory {
	SINGLE_BEHAVIOR_TYPE, SUB_TYPE, MULTI_BEHAVIOR, SUB_TYPE_or_MULTI_BEHAVIOR, SUB_TYPE_and_MULTI_BEHAVIOR, UN_IDd
}
