package ec.app.izhikevich.spike;

public enum PatternType {
	SPIKES, RBASE, SUBSSVOLT, RBOUNDV
}
