package ec.app.izhikevich.exputils;

import java.util.List;

public class ModelConstraints {
	NeuronType neuronType;
	List<SpikePatternTrace> traces;
}
